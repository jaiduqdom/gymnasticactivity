#!/usr/bin/env python
# -*- coding: utf-8 -*-
# From Python
# It requires OpenCV installed for Python
import sys
import cv2
import os
from os import remove
from os import path
import traceback
from os import listdir
from time import time
from angulosLongitudes import angulosLongitudes

# Función para devolver ficheros o directorios de una ruta
def lstPath(path):    
    return [obj for obj in listdir(path)]
    
# Ruta a las clases y los vídeos grabados
PATH_CLASSES = "/home/disa/skeleton/ENTRENAMIENTO/dataset/datasetPosturas"
# Puntos devueltos OpenPose
keyPoints = 25
# Fichero de datos de entrenamiento de la red neuronal
FILE_DATOS = "/home/disa/skeleton/ENTRENAMIENTO/datosEntrenamiento.csv"

""" REVISAR POSTURAS EN EL PAPER
Este programa lee los vídeos que se encuentran en la carpeta dataset agrupados por clases y los procesa para obtener los ángulos y longitudes de los
vectores que serán la entrada del entrenamiento de la red neuronal de detección de postura.

19 posiciones: Ver paper ya que se han cambiado
"""

def procesarVideos():
    
    # Borramos el fichero de salida
    if path.exists(FILE_DATOS):
        remove(FILE_DATOS)
    
    # Funciones para calcular las longitures y ángulos
    aL = angulosLongitudes()    
   
    try:
        # Import Openpose (Windows/Ubuntu/OSX)
        dir_path = os.path.dirname(os.path.realpath(__file__))
        print(dir_path)
        try:
            # Change these variables to point to the correct folder (Release/x64 etc.)
            sys.path.append('/usr/local/python');
            # If you run `make install` (default path is `/usr/local/python` for Ubuntu), you can also access the OpenPose/python module from there. This will install OpenPose and the python library at your desired installation path. Ensure that this is in your python path in order to use it.
            # sys.path.append('/usr/local/python')
            from openpose import pyopenpose as op
        except ImportError as e:
            print('Error: OpenPose library could not be found. Did you enable `BUILD_PYTHON` in CMake and have this Python script in the right folder?')
            raise e
    
        # Flags
        # parser = argparse.ArgumentParser()
        # parser.add_argument("--image_path", default="./izquierda.jpg", help="Process an image. Read all standard formats (jpg, png, bmp, etc.).")
        # args = parser.parse_known_args()
    
        # Custom Params (refer to include/openpose/flags.hpp for more parameters)
        params = dict()
        params["model_folder"] = "/home/disa/skeleton/openpose/models/"
        params["face"] = False
        params["hand"] = False
    
        # Starting OpenPose
        opWrapper = op.WrapperPython()
        opWrapper.configure(params)
        opWrapper.start()

        # Leemos las distintas clases que existen    
        clases = lstPath(PATH_CLASSES)
        for x in range(0, len(clases)):
            archivos = lstPath(PATH_CLASSES + "/" + clases[x])
            for file in archivos:
                #print("Clase " + clases[x])
                #print("Archivo : " + str(file))
                print("Procesando archivo " + str(file) + " de clase " + clases[x] + "...")
    
                # Leemos el fichero con OpenCV
                cap = cv2.VideoCapture(PATH_CLASSES + "/" + clases[x] + "/" + str(file))
    
                # Leemos cada frame, obtenemos su esqueleto, sus valores de entrada de la red, y los escribimos en un CSV    
                while(cap.isOpened()):
                    ret, frame = cap.read()
                    if ret == False:
                        break
                    
                    height, width, channels = frame.shape 
                
                    # Our operations on the frame come here
                    # gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                
                    # Process Image
                    datum = op.Datum()
                    # imageToProcess = cv2.imread(args[0].image_path)
                    datum.cvInputData = frame
                    opWrapper.emplaceAndPop([datum])
                    
                    # print("Body keypoints: \n" + str(datum.poseKeypoints))
                    
                    cadena = ""
                    # Obtenemos las longitudes y los ángulos
                    datos = aL.obtenerAngulosLongitudes(datum.poseKeypoints, 0)
                    
                    if datos != []:
                        tam = len(datos)
                        for i in range(0, tam):
                            cadena = cadena + str(datos[i]) + ","
                        cadena = cadena + clases[x] + "\n"
                
                        with open(FILE_DATOS, 'a') as file:
                            file.write(cadena)
                            
                        #print("Cadena: \n" + str(cadena))
            
                    # Display the resulting frame
                    # cv2.imshow('esqueleto', datum.cvOutputData)
                    
                    # Hand Pose        
                    # https://medium.com/@prasad.pai/classification-of-hand-gesture-pose-using-tensorflow-30e83064e0ed        
                    
                    #if cv2.waitKey(1) & 0xFF == ord('q'):
                    #    break
                    
                    #cv2.imshow("OpenPose 1.5.1 - Tutorial Python API", datum.cvOutputData)
                    #cv2.imwrite("salida.jpg", datum.cvOutputData)
            
                # When everything done, release the capture
                cap.release()
        cv2.destroyAllWindows()
        # cv2.waitKey(0)
        print("Proceso finalizado.")
    except Exception as e:
        traceback.print_exc(file=sys.stdout)    
        print(e)
        raise e
        sys.exit(-1)


def main(args):
    # Tiempo de inicio
    start_time = time()
    # Realizar el procesamiento de los vídeos
    procesarVideos()
    # Tiempo transcurrido
    elapsed_time = time() - start_time
    print("Tiempo total: %0.10f seconds." % elapsed_time)

if __name__ == '__main__':
    main(sys.argv)
