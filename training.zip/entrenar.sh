# Realización del entrenamiento de la red de posturas
python grabarCuerpoAngulos.py
python grabarCuerpoAngulos_VideoTransiciones1.py
python grabarCuerpoAngulos_VideoTransiciones2.py
cp ./dataset/datosEntrenamiento.csv ./dataset/datosEntrenamientoTotal.csv
cat ./dataset/datosEntrenamiento_VideoTransiciones1.csv >> ./dataset/datosEntrenamientoTotal.csv
cat ./dataset/datosEntrenamiento_VideoTransiciones2.csv >> ./dataset/datosEntrenamientoTotal.csv
python entrenarRedCuerpoAngulos.py



