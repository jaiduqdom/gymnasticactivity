#!/usr/bin/env python
# -*- coding: utf-8 -*-
# From Python
# It requires OpenCV installed for Python

# En este segundo programa leemos el video con los ejercicios catalogados manualmente y generamos otro CVS separado del primero.

import sys
import cv2
import os
from os import remove
from os import path
import traceback
from os import listdir
from time import time
from angulosLongitudes import angulosLongitudes

# Función para devolver ficheros o directorios de una ruta
def lstPath(path):    
    return [obj for obj in listdir(path)]
    
# Puntos devueltos OpenPose
keyPoints = 25
# Fichero de datos de entrenamiento de la red neuronal
FILE_DATOS = "/home/disa/skeleton/ENTRENAMIENTO/dataset/datosEntrenamiento_VideoTransiciones1.csv"

""" 
Este programa lee el video de transiciones para crear datos de entrenamiento.

19 posiciones: Las posiciones estan en el paper
"""

def procesarVideos():
    
    # Borramos el fichero de salida
    if path.exists(FILE_DATOS):
        remove(FILE_DATOS)
    
    # Funciones para calcular las longitures y ángulos
    aL = angulosLongitudes()    
   
    try:
        # Import Openpose (Windows/Ubuntu/OSX)
        dir_path = os.path.dirname(os.path.realpath(__file__))
        print(dir_path)
        try:
            # Change these variables to point to the correct folder (Release/x64 etc.)
            sys.path.append('/usr/local/python');
            # If you run `make install` (default path is `/usr/local/python` for Ubuntu), you can also access the OpenPose/python module from there. This will install OpenPose and the python library at your desired installation path. Ensure that this is in your python path in order to use it.
            # sys.path.append('/usr/local/python')
            from openpose import pyopenpose as op
        except ImportError as e:
            print('Error: OpenPose library could not be found. Did you enable `BUILD_PYTHON` in CMake and have this Python script in the right folder?')
            raise e
    
        # Flags
        # parser = argparse.ArgumentParser()
        # parser.add_argument("--image_path", default="./izquierda.jpg", help="Process an image. Read all standard formats (jpg, png, bmp, etc.).")
        # args = parser.parse_known_args()
    
        # Custom Params (refer to include/openpose/flags.hpp for more parameters)
        params = dict()
        params["model_folder"] = "/home/disa/skeleton/openpose/models/"
        params["face"] = False
        params["hand"] = False
    
        # Starting OpenPose
        opWrapper = op.WrapperPython()
        opWrapper.configure(params)
        opWrapper.start()

        # Las clases las tenemos en la tabla de DATOS
        DATOS = [["C", 253, "C"],["H", 62, "C"],["B", 5, "B"],["H", 1, "B"],["B", 3, "B"],["H", 1, "B"],["B", 70, "B"],["M", 1, "B"],
        ["B", 1, "B"],["M", 2, "B"],["B", 6, "B"],["M", 1, "B"],["B", 94, "B"],["M", 1, "B"],["B", 5, "B"],["M", 2, "B"],
        ["B", 46, "B"],["L", 7, "B"],["J", 3, "J"],["M", 2, "J"],["J", 159, "J"],["A", 338, "A"],["D", 90, "M"],["D", 170, "D"],["K", 1, "K"],
        ["D", 1, "K"],["K", 72, "K"],["G", 91, "G"],["C", 94, "C"],["N", 12, "F"],["F", 142, "F"],["B", 155, "B"],["A", 1, "A"],
        ["B", 4, "A"],["A", 134, "A"],["O", 1, "A"],["A", 1, "A"],["O", 1, "A"],["A", 1, "A"],["O", 1, "A"],["A", 1, "A"],
        ["O", 1, "A"],["A", 3, "A"],["O", 2, "A"],["A", 1, "A"],["O", 4, "A"],["A", 36, "A"],["O", 1, "A"],["A", 1, "A"],
        ["O", 1, "A"],["A", 3, "A"],["Q", 9, "A"],["J", 112, "J"],["Q", 137, "Q"],["S", 133, "S"],["Q", 22, "Q"],["S", 1, "Q"],
        ["Q", 30, "Q"],["R", 1, "R"],["Q", 1, "R"],["R", 1, "R"],["Q", 3, "R"],["R", 135, "R"],["Q", 69, "Q"],["S", 106, "S"],
        ["Q", 70, "Q"],["R", 1, "Q"],["Q", 5, "Q"],["R", 128, "R"],["Q", 11, "Q"],["B", 3, "Q"],["J", 23, "J"],["M", 2, "B"],
        ["B", 2, "B"],["M", 10, "B"],["B", 89, "B"],["G", 16, "B"],["C", 2, "C"],["H", 1, "C"],["C", 43, "C"],["N", 136, "N"],
        ["P", 13, "P"],["N", 1, "P"],["P", 83, "P"],["N", 7, "N"],["P", 3, "N"],["N", 1, "N"],["P", 7, "N"],["N", 83, "N"],
        ["O", 2, "O"],["N", 1, "O"],["O", 1, "O"],["N", 1, "O"],["O", 116, "O"],["N", 7, "N"],["O", 1, "N"],["N", 77, "N"],
        ["P", 8, "P"],["N", 1, "P"],["P", 1, "P"],["N", 1, "P"],["P", 52, "P"],["N", 4, "N"],["P", 1, "N"],["N", 7, "N"],
        ["P", 1, "N"],["N", 1, "N"],["P", 5, "N"],["N", 78, "N"],["C", 92, "C"],["G", 6, "G"],["C", 1, "G"],["G", 44, "G"],
        ["K", 82, "K"],["M", 78, "M"],["J", 98, "J"],["Q", 18, "A"],["A", 1, "A"],["Q", 38, "A"],["O", 4, "A"],["R", 1, "A"],
        ["A", 3, "A"],["O", 1, "A"],["A", 4, "A"],["O", 1, "A"],["A", 34, "A"],["O", 1, "A"],["A", 1, "A"],["O", 1, "A"],
        ["A", 46, "A"],["O", 1, "A"],["A", 10, "A"],["O", 1, "A"],["A", 1, "A"],["O", 3, "A"],["A", 7, "A"],["O", 1, "A"],
        ["A", 19, "A"],["O", 1, "A"],["A", 3, "A"],["Q", 2, "A"],["R", 1, "A"],["Q", 8, "A"],["I", 2, "A"],["Q", 4, "A"],
        ["I", 1, "A"],["R", 1, "A"],["Q", 1, "A"],["I", 3, "A"],["Q", 3, "A"],["I", 1, "A"],["Q", 1, "A"],["I", 1, "A"],
        ["Q", 2, "A"],["I", 3, "A"],["Q", 1, "A"],["I", 1, "A"],["Q", 14, "A"],["I", 1, "A"],["Q", 11, "A"],["L", 93, "L"],
        ["I", 78, "I"],["H", 58, "H"],["C", 62, "C"],["H", 20, "B"],["B", 49, "B"],["L", 5, "B"],["J", 83, "J"],["Q", 1, "A"],
        ["J", 1, "A"],["Q", 1, "A"],["A", 39, "A"],["Q", 5, "A"],["A", 40, "A"],["Q", 12, "A"],["A", 1, "A"],["Q", 10, "A"],
        ["J", 1, "A"],["Q", 1, "A"],["J", 16, "A"],["L", 12, "A"],["E", 2, "E"],["L", 1, "E"],["E", 69, "E"],["I", 1, "E"],
        ["E", 4, "E"],["I", 15, "L"],["L", 4, "L"],["G", 1, "G"],["H", 1, "G"],["G", 25, "G"],["K", 41, "K"],["D", 106, "D"],
        ["B", 1, "B"],["D", 1, "B"],["B", 155, "B"],["G", 17, "C"],["C", 3, "C"],["G", 1, "C"],["C", 44, "C"],["N", 9, "F"],
        ["F", 143, "F"],["A", 203, "A"],["F", 132, "F"],["N", 11, "C"],["C", 51, "C"],["H", 20, "B"],["B", 73, "B"],["A", 147, "A"],
        ["O", 1, "A"],["A", 25, "A"],["Q", 17, "J"],["J", 63, "J"],["M", 1, "J"],["J", 1, "J"],["M", 1, "B"],["B", 6, "B"],
        ["M", 1, "B"],["B", 3, "B"],["M", 1, "B"],["B", 75, "B"],["G", 18, "C"],["C", 51, "C"],["N", 113, "N"],["P", 1, "P"],
        ["N", 1, "P"],["P", 6, "P"],["N", 3, "P"],["P", 3, "P"],["N", 1, "P"],["P", 72, "P"],["N", 3, "N"],["P", 5, "N"],
        ["N", 53, "N"],["O", 86, "O"],["N", 104, "N"],["F", 9, "J"],["J", 55, "J"],["Q", 2, "Q"],["J", 1, "Q"],["Q", 86, "Q"],
        ["S", 81, "S"],["Q", 47, "Q"],["R", 87, "R"],["Q", 58, "Q"],["A", 147, "A"],["P", 2, "A"],["A", 33, "A"],["O", 3, "A"],
        ["A", 1, "A"],["O", 1, "A"],["A", 39, "A"],["O", 4, "A"],["A", 73, "A"],["B", 1, "B"],["J", 3, "B"],["B", 5, "B"],
        ["M", 6, "B"],["B", 49, "B"],["H", 13, "B"],["C", 57, "C"],["E", 2, "C"],["C", 4, "C"],["E", 1, "C"]]

        N_FRAMES = int(0)        
        for i in range(0, len(DATOS)):
            N_FRAMES = N_FRAMES + int(DATOS[i][1])

        SECUENCIA_VITERBI = [""] * (N_FRAMES)
        posicion = 0
        for i in range(0, len(DATOS)):
            for j in range(0, DATOS[i][1]):
                SECUENCIA_VITERBI[posicion] = DATOS[i][2]
                posicion = posicion + 1

        posicion = 0
    
        # Leemos el fichero con OpenCV
        cap = cv2.VideoCapture("/home/disa/skeleton/ENTRENAMIENTO/dataset/videoTransiciones1.webm")
        
        # Generamos un video de salida
        frame_width = int(cap.get(3))
        frame_height = int(cap.get(4))  
        salida = cv2.VideoWriter("/home/disa/skeleton/ENTRENAMIENTO/dataset/videoTransiciones1_Resultado.mp4", cv2.VideoWriter_fourcc('M','J','P','G'), 20, (frame_width,frame_height))

        # Leemos cada frame, obtenemos su esqueleto, sus valores de entrada de la red, y los escribimos en un CSV    
        while(cap.isOpened()):
            ret, frame = cap.read()
            if ret == False:
                break
            
            height, width, channels = frame.shape 
        
            # Our operations on the frame come here
            # gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
            # Process Image
            datum = op.Datum()
            # imageToProcess = cv2.imread(args[0].image_path)
            datum.cvInputData = frame
            opWrapper.emplaceAndPop([datum])
            
            # print("Body keypoints: \n" + str(datum.poseKeypoints))
            
            cadena = ""
            # Obtenemos las longitudes y los ángulos
            datos = aL.obtenerAngulosLongitudes(datum.poseKeypoints, 0)
            
            if datos != []:
                tam = len(datos)
                for i in range(0, tam):
                    cadena = cadena + str(datos[i]) + ","
                cadena = cadena + SECUENCIA_VITERBI[posicion] + "\n"
                texto_mostrar = SECUENCIA_VITERBI[posicion]
                
                posicion = posicion + 1
        
                with open(FILE_DATOS, 'a') as file:
                    file.write(cadena)
                    
                cv2.putText(frame, texto_mostrar, (15, 35), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
                salida.write(frame)
            
            # Hand Pose        
            # https://medium.com/@prasad.pai/classification-of-hand-gesture-pose-using-tensorflow-30e83064e0ed        
    
        # When everything done, release the capture
        cap.release()
        cv2.destroyAllWindows()
        # cv2.waitKey(0)
        print("Proceso finalizado.")
    except Exception as e:
        traceback.print_exc(file=sys.stdout)    
        print(e)
        raise e
        sys.exit(-1)


def main(args):
    # Tiempo de inicio
    start_time = time()
    # Realizar el procesamiento de los vídeos
    procesarVideos()
    # Tiempo transcurrido
    elapsed_time = time() - start_time
    print("Tiempo total: %0.10f seconds." % elapsed_time)

if __name__ == '__main__':
    main(sys.argv)
