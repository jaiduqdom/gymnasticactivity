# https://machinelearningmastery.com/tensorflow-tutorial-deep-learning-with-tf-keras/
# mlp for binary classification
"""from pandas import read_csv
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense
# load the dataset
path = 'manos.csv'
df = read_csv(path, header=None)
# split into input and output columns
X, y = df.values[:, :-1], df.values[:, -1]
# ensure all data are floating point values
X = X.astype('float32')
# encode strings to integer
y = LabelEncoder().fit_transform(y)

# split into train and test datasets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33)
print(X_train.shape, X_test.shape, y_train.shape, y_test.shape)
# determine the number of input features
n_features = X_train.shape[1]
# define model
model = Sequential()
model.add(Dense(20, activation='relu', kernel_initializer='he_normal', input_shape=(n_features,)))
model.add(Dense(8, activation='relu', kernel_initializer='he_normal'))
model.add(Dense(1, activation='sigmoid'))
# compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
# fit the model
model.fit(X_train, y_train, epochs=150, batch_size=32, verbose=0)
# evaluate the model
loss, acc = model.evaluate(X_test, y_test, verbose=0)
print('Test Accuracy: %.3f' % acc)
# make a prediction
row = [0.0209200382233,0.095926062266,0.0413298606873,0.0768769264221,0.059698677063,0.0435409228007,0.0571474075317,0.0142868359884,0.0423503398895,0.00680325826009,0.0443912982941,0.00884424845378,0.0367376327515,0.0,0.0367376327515,0.016327826182,0.0438810825348,0.0326556523641,0.0275532245636,0.016327826182,0.0219405174255,0.0102048873901,0.0270429611206,0.0312950134277,0.0326556682587,0.0455818494161,0.0142868518829,0.0265327135722,0.0107151508331,0.0210901260376,0.0158175945282,0.0421802202861,0.0209200382233,0.0537458101908,0.00459218025208,0.038098303477,0.0,0.0374179522196,0.00102047920227,0.0530654589335,0.00510244369507,0.0605490684509]
yhat = model.predict([row])
print('Predicted: %.3f' % yhat)


Inicio:

model = Sequential()
model.add(Dense(20, activation='relu', kernel_initializer='he_normal', input_shape=(n_features,)))
model.add(Dense(8, activation='relu', kernel_initializer='he_normal'))
model.add(Dense(1, activation='sigmoid'))

Test Accuracy: 0.439
Predicted: 1.000


"""

# mlp for multiclass classification
from numpy import argmax
from pandas import read_csv
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense
import tensorflow as tf
import numpy as np
from time import time
import csv

# Tiempo de inicio
start_time = time()

# load the dataset
path = 'dataset/datosEntrenamientoTotal.csv'
df = read_csv(path, header=None)
# split into input and output columns
X, y = df.values[:, :-1], df.values[:, -1]
# ensure all data are floating point values
X = X.astype('float32')
# encode strings to integer
y = LabelEncoder().fit_transform(y)
# split into train and test datasets
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33)
print(X_train.shape, X_test.shape, y_train.shape, y_test.shape)
# determine the number of input features
n_features = X_train.shape[1]
# define model
model = Sequential()
#model.add(Dense(n_features*19, activation='relu', kernel_initializer='he_normal', input_shape=(n_features,)))

# Parametros de la red
# https://stats.stackexchange.com/questions/181/how-to-choose-the-number-of-hidden-layers-and-nodes-in-a-feedforward-neural-netw

#samples = float(101807)
samples = float(118718)
#samples = float(109880)

n_i = float(n_features)
n_o = float(19)
alpha = float(3)
#n_h = 101807 / (alpha * (n_i + n_o))
#n_h = 109880 / (alpha * (n_i + n_o))
n_h = 118718 / (alpha * (n_i + n_o))
neuronas_ocultas = int(n_h)

model.add(Dense(neuronas_ocultas, activation='relu', kernel_initializer='he_normal', input_shape=(n_features,)))

#model.add(Dense(64, activation='relu', kernel_initializer='he_normal'))
#model.add(Dense(64, activation='relu', kernel_initializer='he_normal'))
model.add(Dense(19, activation='softmax'))
# compile the model
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
# fit the model
model.fit(X_train, y_train, epochs=150, batch_size=32, verbose=0)
# evaluate the model
loss, acc = model.evaluate(X_test, y_test, verbose=0)
print('Test Accuracy: %.3f' % acc)
# make a prediction
# row = [0.0209200382233,0.095926062266,0.0413298606873,0.0768769264221,0.059698677063,0.0435409228007,0.0571474075317,0.0142868359884,0.0423503398895,0.00680325826009,0.0443912982941,0.00884424845378,0.0367376327515,0.0,0.0367376327515,0.016327826182,0.0438810825348,0.0326556523641,0.0275532245636,0.016327826182,0.0219405174255,0.0102048873901,0.0270429611206,0.0312950134277,0.0326556682587,0.0455818494161,0.0142868518829,0.0265327135722,0.0107151508331,0.0210901260376,0.0158175945282,0.0421802202861,0.0209200382233,0.0537458101908,0.00459218025208,0.038098303477,0.0,0.0374179522196,0.00102047920227,0.0530654589335,0.00510244369507,0.0605490684509]
# yhat = model.predict([row])
# print('Predicted: %s (class=%d)' % (yhat, argmax(yhat)))
model.save('modeloPosturas.h5') 

# Tiempo transcurrido
elapsed_time = time() - start_time
print("Tiempo total: %0.10f seconds." % elapsed_time)

# Evaluar los casos de test del fichero
#model = tf.keras.models.load_model('modeloPosturas.h5')

correctos = float(0)
totales = float(0)
with open(path) as File:
    reader = csv.reader(File, delimiter=',', quotechar=',',
                        quoting=csv.QUOTE_MINIMAL)
    for row in reader:
        
        row2 = np.zeros(len(row)-1)
        for i in range(0, len(row)-1):
            row2[i] = float(row[i])
        
        yhat = model.predict([[row2]])
        salida = row[len(row)-1]
        test = -1
        if salida == "A":
            test = 0
        if salida == "B":
            test = 1
        if salida == "C":
            test = 2
        if salida == "D":
            test = 3
        if salida == "E":
            test = 4
        if salida == "F":
            test = 5
        if salida == "G":
            test = 6
        if salida == "H":
            test = 7
        if salida == "I":
            test = 8
        if salida == "J":
            test = 9
        if salida == "K":
            test = 10
        if salida == "L":
            test = 11
        if salida == "M":
            test = 12
        if salida == "N":
            test = 13
        if salida == "O":
            test = 14
        if salida == "P":
            test = 15
        if salida == "Q":
            test = 16
        if salida == "R":
            test = 17
        if salida == "S":
            test = 18
        totales = totales + 1
        if test == argmax(yhat):
            correctos = correctos + 1
            
print("Resultado final sobre todo el juego de datos...")
resultado = round( 100 * correctos /  totales, 2)
print("Exito = " + str(resultado))
