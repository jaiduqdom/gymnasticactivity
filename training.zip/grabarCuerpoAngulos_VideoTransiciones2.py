#!/usr/bin/env python
# -*- coding: utf-8 -*-
# From Python
# It requires OpenCV installed for Python

# En este segundo programa leemos el video con los ejercicios catalogados manualmente y generamos otro CVS separado del primero.

import sys
import cv2
import os
from os import remove
from os import path
import traceback
from os import listdir
from time import time
from angulosLongitudes import angulosLongitudes

# Función para devolver ficheros o directorios de una ruta
def lstPath(path):    
    return [obj for obj in listdir(path)]
    
# Puntos devueltos OpenPose
keyPoints = 25
# Fichero de datos de entrenamiento de la red neuronal
FILE_DATOS = "/home/disa/skeleton/ENTRENAMIENTO/dataset/datosEntrenamiento_VideoTransiciones2.csv"

""" 
Este programa lee el video de transiciones para crear datos de entrenamiento.

19 posiciones: Las posiciones estan en el paper
"""

def procesarVideos():
    
    # Borramos el fichero de salida
    if path.exists(FILE_DATOS):
        remove(FILE_DATOS)
    
    # Funciones para calcular las longitures y ángulos
    aL = angulosLongitudes()    
   
    try:
        # Import Openpose (Windows/Ubuntu/OSX)
        dir_path = os.path.dirname(os.path.realpath(__file__))
        print(dir_path)
        try:
            # Change these variables to point to the correct folder (Release/x64 etc.)
            sys.path.append('/usr/local/python');
            # If you run `make install` (default path is `/usr/local/python` for Ubuntu), you can also access the OpenPose/python module from there. This will install OpenPose and the python library at your desired installation path. Ensure that this is in your python path in order to use it.
            # sys.path.append('/usr/local/python')
            from openpose import pyopenpose as op
        except ImportError as e:
            print('Error: OpenPose library could not be found. Did you enable `BUILD_PYTHON` in CMake and have this Python script in the right folder?')
            raise e
    
        # Flags
        # parser = argparse.ArgumentParser()
        # parser.add_argument("--image_path", default="./izquierda.jpg", help="Process an image. Read all standard formats (jpg, png, bmp, etc.).")
        # args = parser.parse_known_args()
    
        # Custom Params (refer to include/openpose/flags.hpp for more parameters)
        params = dict()
        params["model_folder"] = "/home/disa/skeleton/openpose/models/"
        params["face"] = False
        params["hand"] = False
    
        # Starting OpenPose
        opWrapper = op.WrapperPython()
        opWrapper.configure(params)
        opWrapper.start()

        # Las clases las tenemos en la tabla de DATOS
        DATOS = [["C", 135], ["B", 108], ["J", 92], ["A", 78], ["J", 63], ["B", 3], ["B", 59], ["C", 113], 
                ["B", 50], ["J", 93], ["A", 61], ["J", 14], ["Q", 83], ["Q", 7], ["Q", 1], ["S", 1], 
                ["S", 49], ["S", 1], ["S", 1], ["S", 13], ["S", 1], ["S", 13], ["S", 1], ["S", 13], ["S", 7], ["Q", 82], 
                ["R", 1], ["R", 70], ["Q", 1], ["Q", 90], ["Q", 1], ["Q", 1], ["Q", 1], ["S", 114], ["S", 1], ["S", 5], 
                ["Q", 2], ["Q", 1], ["Q", 57], ["R", 1], ["R", 68], ["Q", 1], ["Q", 62], ["Q", 1], ["Q", 1], ["S", 8], 
                ["S", 34], ["S", 24], ["S", 29], ["S", 1], ["Q", 79], ["R", 1], ["R", 62], ["R", 1], ["Q", 65], ["S", 42], 
                ["S", 12], ["S", 1], ["S", 2], ["Q", 1], ["Q", 3], ["Q", 89], ["Q", 4], ["A", 45], ["J", 33], ["B", 2], 
                ["B", 38], ["C", 116], ["N", 145], ["P", 110], ["P", 2], ["P", 2], ["N", 3], ["N", 2], ["N", 78], 
                ["O", 24], ["O", 1], ["O", 48], ["N", 52], ["P", 10], ["P", 14], ["P", 6], ["P", 2], ["P", 2], ["P", 2], 
                ["P", 2], ["P", 18], ["P", 7], ["P", 23], ["N", 3], ["N", 53], ["O", 48], ["O", 2], ["O", 7], ["N", 58], 
                ["P", 2], ["P", 10], ["P", 15], ["P", 36], ["P", 9], ["P", 3], ["P", 8], ["N", 55], ["C", 123], ["G", 55], 
                ["K", 49], ["D", 72], ["K", 41], ["G", 38], ["C", 68], ["H", 62], ["I", 46], ["E", 82], ["I", 41],                 
                ["H", 46], ["C", 538], ["B", 50], ["J", 55], ["A", 68], ["J", 5], ["Q", 75], ["A", 61], ["J", 5], 
                ["Q", 50], ["J", 6], ["A", 44], ["J", 5], ["Q", 57], ["J", 5], ["A", 47], ["J", 5], ["Q", 119], ["J", 48], 
                ["B", 10], ["B", 47], ["C", 244], ["G", 50], ["K", 52], ["M", 84], ["D", 101], ["K", 49], ["G", 52], 
                ["C", 115], ["H", 70], ["I", 57], ["L", 81], ["E", 77], ["I", 61], ["H", 2], ["H", 1], ["H", 1], ["H", 2], 
                ["H", 49], ["C", 145], ["B", 47], ["J", 65], ["A", 105], ["J", 48], ["J", 2], ["B", 39], ["C", 157], 
                ["G", 32], ["K", 57], ["D", 75], ["K", 38], ["G", 42], ["C", 78], ["H", 52], ["I", 47], ["E", 66], 
                ["I", 65], ["H", 43], ["C", 69], ["N", 153], ["P", 56], ["N", 91], ["O", 72], ["N", 84], ["P", 61], 
                ["N", 76], ["O", 62], ["N", 71], ["P", 5], ["P", 3], ["P", 2], ["P", 1], ["P", 35], ["N", 72], ["O", 70], 
                ["N", 70], ["P", 40], ["N", 57], ["C", 88], ["B", 41], ["J", 49], ["A", 47], ["J", 2], ["Q", 91], ["S", 3], 
                ["S", 1], ["S", 49], ["Q", 1], ["Q", 1], ["Q", 83], ["R", 13], ["R", 1], ["R", 40], ["Q", 1], ["S", 11], 
                ["Q", 75], ["S", 59], ["Q", 60], ["R", 13], ["R", 1], ["R", 26], ["R", 1], ["R", 8], ["Q", 112], ["J", 2], 
                ["A", 47], ["J", 28], ["B", 39], ["C", 49]]

        N_FRAMES = int(0)        
        for i in range(0, len(DATOS)):
            N_FRAMES = N_FRAMES + int(DATOS[i][1])

        SECUENCIA_VITERBI = [""] * (N_FRAMES)
        posicion = 0
        for i in range(0, len(DATOS)):
            for j in range(0, DATOS[i][1]):
                SECUENCIA_VITERBI[posicion] = DATOS[i][0]
                posicion = posicion + 1

        posicion = 0
    
        # Leemos el fichero con OpenCV
        cap = cv2.VideoCapture("/home/disa/skeleton/ENTRENAMIENTO/dataset/videoTransiciones2.mp4")
        
        # Generamos un video de salida
        frame_width = int(cap.get(3))
        frame_height = int(cap.get(4))  
        salida = cv2.VideoWriter("/home/disa/skeleton/ENTRENAMIENTO/dataset/videoTransiciones2_Resultado.avi", cv2.VideoWriter_fourcc('M','J','P','G'), 20, (frame_width,frame_height))

        # Leemos cada frame, obtenemos su esqueleto, sus valores de entrada de la red, y los escribimos en un CSV    
        while(cap.isOpened()):
            ret, frame = cap.read()
            if ret == False:
                break
            
            height, width, channels = frame.shape 
        
            # Our operations on the frame come here
            # gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
            # Process Image
            datum = op.Datum()
            # imageToProcess = cv2.imread(args[0].image_path)
            datum.cvInputData = frame
            opWrapper.emplaceAndPop([datum])
            
            # print("Body keypoints: \n" + str(datum.poseKeypoints))
            
            cadena = ""
            # Obtenemos las longitudes y los ángulos
            datos = aL.obtenerAngulosLongitudes(datum.poseKeypoints, 0)
            
            if datos != []:
                tam = len(datos)
                for i in range(0, tam):
                    cadena = cadena + str(datos[i]) + ","
                cadena = cadena + SECUENCIA_VITERBI[posicion] + "\n"
                texto_mostrar = SECUENCIA_VITERBI[posicion]
                
                posicion = posicion + 1
        
                with open(FILE_DATOS, 'a') as file:
                    file.write(cadena)
                    
                cv2.putText(frame, texto_mostrar, (15, 35), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
                salida.write(frame)
            
            # Hand Pose        
            # https://medium.com/@prasad.pai/classification-of-hand-gesture-pose-using-tensorflow-30e83064e0ed        
    
        # When everything done, release the capture
        cap.release()
        cv2.destroyAllWindows()
        # cv2.waitKey(0)
        print("Proceso finalizado.")
    except Exception as e:
        traceback.print_exc(file=sys.stdout)    
        print(e)
        raise e
        sys.exit(-1)


def main(args):
    # Tiempo de inicio
    start_time = time()
    # Realizar el procesamiento de los vídeos
    procesarVideos()
    # Tiempo transcurrido
    elapsed_time = time() - start_time
    print("Tiempo total: %0.10f seconds." % elapsed_time)

if __name__ == '__main__':
    main(sys.argv)
